#!/usr/bin/env python
# encoding: utf-8
# Thomas Nagy, 2005 (ita)
