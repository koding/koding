title: The Videos from the Meetup
author: ryandahl
date: Fri Aug 12 2011 00:14:34 GMT-0700 (PDT)
status: publish
category: Uncategorized
slug: the-videos-from-node-meetup

Uber, Voxer, and Joyent described how they use Node in production

<a href="http://joyeur.com/2011/08/11/node-js-meetup-distributed-web-architectures/">http://joyeur.com/2011/08/11/node-js-meetup-distributed-web-architectures/</a>
