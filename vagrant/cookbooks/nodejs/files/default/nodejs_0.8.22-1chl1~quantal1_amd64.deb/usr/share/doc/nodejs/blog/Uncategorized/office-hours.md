title: Office Hours
author: ryandahl
date: Wed Mar 23 2011 21:42:47 GMT-0700 (PDT)
status: publish
category: Uncategorized
slug: office-hours

Starting next Thursday Isaac, Tom, and I will be holding weekly office hours at <a href="http://maps.google.com/maps?q=345+California+St,+San+Francisco,+CA+94104&amp;layer=c&amp;sll=37.793040,-122.400491&amp;cbp=13,178.31,,0,-60.77&amp;cbll=37.793131,-122.400484&amp;hl=en&amp;sspn=0.006295,0.006295&amp;ie=UTF8&amp;hq=&amp;hnear=345+California+St,+San+Francisco,+California+94104&amp;ll=37.793131,-122.400484&amp;spn=0.001295,0.003428&amp;z=19&amp;panoid=h0dlz3VG-hMKlzOu0LxMIg">Joyent HQ</a> in San Francisco. Office hours are meant to be subdued working time - there are no talks and no alcohol. Bring your bugs or just come and hack with us.

Our building requires that everyone attending be on a list so you must sign up at <a href="http://nodeworkup01.eventbrite.com/">Event Brite</a>.

We start at 4p and end promptly at 8p.
