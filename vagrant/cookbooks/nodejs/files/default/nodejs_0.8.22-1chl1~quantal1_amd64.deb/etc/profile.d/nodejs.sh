
NODE_PATH=/usr/lib/nodejs:/usr/share/javascript
export NODE_PATH

