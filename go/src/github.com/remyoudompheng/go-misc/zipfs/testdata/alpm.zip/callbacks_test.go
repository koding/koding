package alpm

import (
	"testing"
)

func TestLogging(t *testing.T) {
	h, err := Init(root, dbpath)
	if err != nil {
		t.Fatal(err)
	}
	h.SetLogCallback(DefaultLogCallback)
	DefaultLogLevel = LogDebug
	h.LocalDb()
	defer h.Release()
}
